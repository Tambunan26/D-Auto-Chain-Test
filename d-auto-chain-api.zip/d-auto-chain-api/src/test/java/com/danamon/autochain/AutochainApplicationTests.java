package com.danamon.autochain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutochainApplicationTests {

	@Test
	void contextLoads() {
	}

}
