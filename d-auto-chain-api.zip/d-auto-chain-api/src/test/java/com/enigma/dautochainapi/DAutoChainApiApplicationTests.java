package com.enigma.dautochainapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DAutoChainApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
