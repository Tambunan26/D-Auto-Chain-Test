package com.danamon.autochain.dto.backoffice;

public class BackofficeRelationManagementRequest {
}
