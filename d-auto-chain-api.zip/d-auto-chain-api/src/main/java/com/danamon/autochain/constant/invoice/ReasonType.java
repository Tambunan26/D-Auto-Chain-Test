package com.danamon.autochain.constant.invoice;

public enum ReasonType {
    QUANTITY_DISCREPANCIES,
    PRICE_DISCREPANCIES,
    QUALITY_ISSUES,
    OTHER
}
