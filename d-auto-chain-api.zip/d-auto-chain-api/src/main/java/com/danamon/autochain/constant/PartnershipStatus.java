package com.danamon.autochain.constant;

public enum PartnershipStatus {
    PENDING, IN_PARTNER
}
