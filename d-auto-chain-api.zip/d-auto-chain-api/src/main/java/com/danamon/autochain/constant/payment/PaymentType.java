package com.danamon.autochain.constant.payment;

public enum PaymentType {
    FINANCING_PAYABLE, FINANCING_RECEIVABLE ,INVOICING, PARTIAL_FINANCING
}
