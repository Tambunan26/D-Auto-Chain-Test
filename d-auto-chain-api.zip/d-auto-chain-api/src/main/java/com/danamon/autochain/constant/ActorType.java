package com.danamon.autochain.constant;

public enum ActorType {
    BACKOFFICE,
    USER;
    public String getName() {
        return this.name();
    }
}
