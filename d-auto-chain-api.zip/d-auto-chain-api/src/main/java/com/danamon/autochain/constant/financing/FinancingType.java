package com.danamon.autochain.constant.financing;

public enum FinancingType {
    PAYABLE,
    RECEIVABLE
}
