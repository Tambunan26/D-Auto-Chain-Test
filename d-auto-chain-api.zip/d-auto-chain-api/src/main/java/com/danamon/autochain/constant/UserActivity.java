package com.danamon.autochain.constant;

public enum UserActivity {
    LOGIN, FINANCING, INVOICING, PAYMENT, LOGOUT
}
