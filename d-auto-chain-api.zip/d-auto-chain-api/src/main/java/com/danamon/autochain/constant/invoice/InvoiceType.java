package com.danamon.autochain.constant.invoice;

public enum InvoiceType {
        PAYABLE, RECEIVABLE
}
