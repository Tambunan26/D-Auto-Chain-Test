package com.danamon.autochain.constant.invoice;

public enum ProcessingStatusType {
    CANCEL_INVOICE,
    REJECT_INVOICE,
    RESOLVE_INVOICE,
    APPROVE_INVOICE,
    WAITING_STATUS
}
