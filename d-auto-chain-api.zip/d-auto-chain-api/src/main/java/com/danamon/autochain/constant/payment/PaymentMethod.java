package com.danamon.autochain.constant.payment;

public enum PaymentMethod {
    AUTO_DEBIT, BANK_TRANSFER
}
